function App() {
    return `
        ${Header()}
        ${Hero()}
        ${About()}
        ${Features()}
        ${Download()}
        ${Support()}
        ${Footer()}
    `;
}

