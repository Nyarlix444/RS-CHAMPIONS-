function Header() {
    return `
        <header class="header">
            <nav class="nav">
                <a href="#" class="logo">RS CHAMPIONS</a>
                <ul class="nav-menu" id="nav-menu">
                    <li><a href="#home" class="nav-link">Home</a></li>
                    <li><a href="#about" class="nav-link">About</a></li>
                    <li><a href="#features" class="nav-link">Features</a></li>
                    <li><a href="#download" class="nav-link">Download</a></li>
                    <li><a href="#support" class="nav-link">Support</a></li>
                </ul>
                <div class="hamburger" id="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </nav>
        </header>
    `;
}

