function About() {
    return `
        <section class="about" id="about">
            <div class="container">
                <h2 class="section-title">About Victory One</h2>
                <div class="about-content">
                    <p>Victory One is the ultimate gaming platform where players compete, win, and earn real money in a fair gaming environment. Our platform ensures that every player has an equal opportunity to showcase their skills and compete at the highest level.</p>
                    <br>
                    <p>Join thousands of gamers worldwide who have already discovered the thrill of competitive gaming with real rewards. Experience the future of gaming where your skills translate into real earnings.</p>
                </div>
            </div>
        </section>
    `;
}

