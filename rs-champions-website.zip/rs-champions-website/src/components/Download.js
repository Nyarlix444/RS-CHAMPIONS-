function Download() {
    return `
        <section class="download" id="download">
            <div class="container">
                <h2 class="section-title">Download Victory One</h2>
                <div class="download-content">
                    <img src="src/assets/logo.jpg" alt="Victory One Logo" class="app-logo">
                    <p>Click the button below to download and start playing!</p>
                    <br>
                    <a href="#" class="cta-button">Download Now</a>
                </div>
            </div>
        </section>
    `;
}

