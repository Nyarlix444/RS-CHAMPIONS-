function Features() {
    return `
        <section class="features" id="features">
            <div class="container">
                <h2 class="section-title">Features</h2>
                <div class="features-grid">
                    <div class="feature-card">
                        <div class="feature-icon">🎮</div>
                        <h3>Fair Play</h3>
                        <p>Ensuring a level playing field for all gamers with advanced anti-cheat systems and fair matchmaking.</p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">⚡</div>
                        <h3>Fast Performance</h3>
                        <p>Optimized for smooth gameplay with no lags. Experience lightning-fast response times and seamless gaming.</p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">💰</div>
                        <h3>Earn Real Money</h3>
                        <p>Win cash prizes by competing in tournaments and showcasing your gaming skills against top players.</p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">🔒</div>
                        <h3>Secure Transactions</h3>
                        <p>Safe and fast withdrawals for your earnings with bank-level security and encrypted transactions.</p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">📊</div>
                        <h3>Global Leaderboards</h3>
                        <p>Compete with top players worldwide and rank up on our global leaderboards to showcase your skills.</p>
                    </div>
                    <div class="feature-card">
                        <div class="feature-icon">🎭</div>
                        <h3>Custom Avatars</h3>
                        <p>Create your unique gaming identity with customizable avatars and personalized gaming profiles.</p>
                    </div>
                </div>
            </div>
        </section>
    `;
}

