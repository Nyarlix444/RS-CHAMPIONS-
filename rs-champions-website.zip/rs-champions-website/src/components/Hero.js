function Hero() {
    return `
        <section class="hero" id="home">
            <div class="hero-content">
                <h1>RS CHAMPIONS</h1>
                <p>The ultimate gaming platform where players compete, win, and earn real money in a fair gaming environment.</p>
                <a href="#download" class="cta-button">Download Now</a>
            </div>
        </section>
    `;
}

