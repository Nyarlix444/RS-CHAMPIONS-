function Footer() {
    return `
        <footer class="footer">
            <div class="container">
                <p>&copy; 2025 Victory One. All rights reserved.</p>
            </div>
        </footer>
    `;
}

