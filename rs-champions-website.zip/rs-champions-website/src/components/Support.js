function Support() {
    return `
        <section class="support" id="support">
            <div class="container">
                <h2 class="section-title">Support</h2>
                <div class="support-content">
                    <p>Need help? Our support team is available 24/7 to assist you.</p>
                    <p>For account-related problems, payment issues, or general inquiries, reach out to us.</p>
                    <br>
                    <p><strong>Email:</strong></p>
                    <a href="mailto:Pateldharmiks2010@gmail.com" class="email-link">Pateldharmiks2010@gmail.com</a>
                    <br><br>
                    <p>We usually respond within 24 hours. Thank you for being a part of Victory One!</p>
                </div>
            </div>
        </section>
    `;
}

