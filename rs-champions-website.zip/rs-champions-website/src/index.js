// Import all components
document.addEventListener('DOMContentLoaded', function() {
    // Load all component scripts
    const scripts = [
        'src/components/Header.js',
        'src/components/Hero.js',
        'src/components/About.js',
        'src/components/Features.js',
        'src/components/Download.js',
        'src/components/Support.js',
        'src/components/Footer.js',
        'src/App.js'
    ];

    let loadedScripts = 0;

    scripts.forEach(src => {
        const script = document.createElement('script');
        script.src = src;
        script.onload = () => {
            loadedScripts++;
            if (loadedScripts === scripts.length) {
                // All scripts loaded, render the app
                document.getElementById('root').innerHTML = App();
                initializeEventListeners();
            }
        };
        document.head.appendChild(script);
    });
});

function initializeEventListeners() {
    // Mobile menu toggle
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('nav-menu');

    if (hamburger && navMenu) {
        hamburger.addEventListener('click', () => {
            navMenu.classList.toggle('active');
        });
    }

    // Smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
            
            // Close mobile menu if open
            if (navMenu.classList.contains('active')) {
                navMenu.classList.remove('active');
            }
        });
    });

    // Smooth scrolling for CTA buttons
    const ctaButtons = document.querySelectorAll('.cta-button');
    ctaButtons.forEach(button => {
        if (button.getAttribute('href') === '#download') {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                const downloadSection = document.getElementById('download');
                if (downloadSection) {
                    downloadSection.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        }
    });

    // Add scroll effect to header
    window.addEventListener('scroll', () => {
        const header = document.querySelector('.header');
        if (window.scrollY > 100) {
            header.style.background = 'linear-gradient(135deg, rgba(255, 0, 0, 0.95), rgba(204, 0, 0, 0.95))';
            header.style.backdropFilter = 'blur(10px)';
        } else {
            header.style.background = 'linear-gradient(135deg, #ff0000, #cc0000)';
            header.style.backdropFilter = 'none';
        }
    });
}

